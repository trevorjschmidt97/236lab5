#ifndef Tuple_h
#define Tuple_h

#include <string>
#include <vector>

using namespace std;

class Tuple : public vector<string>
{
public:

private:

};

#endif //Tuple_h



